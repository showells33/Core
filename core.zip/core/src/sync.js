import { db } from "./db.js";
import { state } from "./state.js";

const LATEST_URL = "https://YOUR-WORKER.workers.dev/latest";

function setBadge(el, text){
  if (!el) return;
  el.textContent = text || "";
}

async function getLastSeen(){
  const meta = await db.get("meta", "last_seen");
  return meta?.value || null;
}
async function setLastSeen(value){
  await db.put("meta", { key:"last_seen", value });
}

function extractHealthPatch(payload){
  // Temporary: expects normalized keys. We will map Health Auto Export after you send a sample.
  return {
    steps: payload.steps ?? null,
    activeCalories: payload.activeCalories ?? null,
    sleepMin: payload.sleepMin ?? null,
    rhr: payload.rhr ?? null,
    hrv: payload.hrv ?? null,
  };
}

export function startAutoSync({ badgeEl, intervalMs = 300000 }){
  async function tick(){
    try{
      setBadge(badgeEl, "Syncing…");
      const res = await fetch(LATEST_URL, { cache: "no-store" });
      const payload = await res.json();

      if (payload?.empty) { setBadge(badgeEl, "No health data yet"); return; }

      const receivedAt = payload._received_at || payload.received_at || null;
      const lastSeen = await getLastSeen();

      if (receivedAt && lastSeen === receivedAt) { setBadge(badgeEl, "Up to date"); return; }

      const patch = extractHealthPatch(payload);
      await state.mergeHealth(patch);

      if (receivedAt) await setLastSeen(receivedAt);
      setBadge(badgeEl, "Updated");
      setTimeout(() => setBadge(badgeEl, "Up to date"), 1500);
    } catch {
      setBadge(badgeEl, "Offline");
    }
  }

  tick();
  const timer = setInterval(tick, intervalMs);

  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) tick();
  });

  return () => clearInterval(timer);
}