export const db = {
  _db: null,

  async open(){
    return new Promise((resolve, reject) => {
      const req = indexedDB.open("core_db_v1", 1);
      req.onupgradeneeded = () => {
        const d = req.result;
        d.createObjectStore("profile", { keyPath: "id" });
        d.createObjectStore("daily", { keyPath: "date" });
        d.createObjectStore("meta", { keyPath: "key" });
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  },

  async tx(store, mode="readonly"){
    const d = this._db;
    return d.transaction(store, mode).objectStore(store);
  },

  async get(store, key){
    const os = await this.tx(store);
    return new Promise((resolve, reject) => {
      const req = os.get(key);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  },

  async getAll(store){
    const os = await this.tx(store);
    return new Promise((resolve, reject) => {
      const req = os.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  },

  async put(store, value){
    const os = await this.tx(store, "readwrite");
    return new Promise((resolve, reject) => {
      const req = os.put(value);
      req.onsuccess = () => resolve(true);
      req.onerror = () => reject(req.error);
    });
  }
};

export async function initDB(){
  db._db = await db.open();
}