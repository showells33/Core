import { Dashboard } from "./screens/dashboard.js";
import { Train } from "./screens/train.js";
import { Log } from "./screens/log.js";
import { Analytics } from "./screens/analytics.js";
import { state } from "./state.js";

const routes = {
  "#/dashboard": Dashboard,
  "#/train": Train,
  "#/log": Log,
  "#/analytics": Analytics,
};

export const router = {
  viewEl: null,

  init(viewEl){
    this.viewEl = viewEl;

    window.addEventListener("hashchange", () => this.render());
    if (!location.hash) location.hash = "#/dashboard";
    this.render();

    state.subscribe(() => this.render());
  },

  render(){
    const Screen = routes[location.hash] || Dashboard;
    this.viewEl.innerHTML = "";
    this.viewEl.appendChild(Screen());
  }
};