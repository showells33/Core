import { db } from "./db.js";
import { computeReadiness } from "./readiness.js";

function todayKey(){
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth()+1).padStart(2,"0");
  const dd = String(d.getDate()).padStart(2,"0");
  return `${yyyy}-${mm}-${dd}`;
}

const defaultProfile = {
  name: "Steve",
  mode: "strict",
  aggressiveness: 7,
  goalWeight: 175,
  caloriesTarget: 2250,
  proteinTarget: 190,
  carbsTarget: 220,
  fatTarget: 70,
  weighInRequired: true,
};

export const state = {
  listeners: new Set(),
  profile: { ...defaultProfile },
  daily: {},

  subscribe(fn){ this.listeners.add(fn); return () => this.listeners.delete(fn); },
  emit(){ for (const fn of this.listeners) fn(); },

  getToday(){
    const k = todayKey();
    if (!this.daily[k]) {
      this.daily[k] = {
        date: k,
        weightAM: null,
        macros: { calories: 0, protein: 0, carbs: 0, fat: 0 },
        health: { steps: null, activeCalories: null, sleepMin: null, rhr: null, hrv: null },
        readiness: { score: null, color: "yellow", updatedAt: null },
      };
    }
    return this.daily[k];
  },

  async hydrate(){
    const savedProfile = await db.get("profile", "main");
    if (savedProfile) this.profile = savedProfile;

    const allDaily = await db.getAll("daily");
    this.daily = {};
    for (const d of allDaily) this.daily[d.date] = d;

    this.getToday();
    await this.recomputeReadiness();
    this.emit();
  },

  async saveProfile(){
    await db.put("profile", { id:"main", ...this.profile });
    this.emit();
  },

  async saveToday(){
    const t = this.getToday();
    await db.put("daily", t);
    this.emit();
  },

  async setWeightAM(value){
    const t = this.getToday();
    t.weightAM = value;
    await this.saveToday();
    await this.recomputeReadiness();
  },

  async addMacros(delta){
    const t = this.getToday();
    t.macros.calories += delta.calories || 0;
    t.macros.protein += delta.protein || 0;
    t.macros.carbs += delta.carbs || 0;
    t.macros.fat += delta.fat || 0;
    await this.saveToday();
  },

  async mergeHealth(healthPatch){
    const t = this.getToday();
    t.health = { ...t.health, ...healthPatch };
    await this.saveToday();
    await this.recomputeReadiness();
  },

  async recomputeReadiness(){
    const t = this.getToday();
    const { score, color } = computeReadiness({
      profile: this.profile,
      today: t,
      history: Object.values(this.daily).slice(-14),
    });
    t.readiness = { score, color, updatedAt: new Date().toISOString() };
    await db.put("daily", t);
    this.emit();
  }
};