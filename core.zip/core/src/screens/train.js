import { el, card } from "../ui/components.js";

export function Train(){
  return el("div", { class:"stack" }, [
    card("Train", [
      el("div", { class:"meta" }, ["Workout engine will be added next."])
    ])
  ]);
}