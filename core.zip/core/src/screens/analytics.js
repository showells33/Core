import { el, card } from "../ui/components.js";

export function Analytics(){
  return el("div", { class:"stack" }, [
    card("Analytics", [
      el("div", { class:"meta" }, ["Trends + export will be added next."])
    ])
  ]);
}