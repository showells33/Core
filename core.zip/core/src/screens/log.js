import { el, card } from "../ui/components.js";

export function Log(){
  return el("div", { class:"stack" }, [
    card("Log", [
      el("div", { class:"meta" }, ["Food photo AI + manual meals will be added next."])
    ])
  ]);
}