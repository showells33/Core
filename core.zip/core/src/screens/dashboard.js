import { state } from "../state.js";
import { el, card, badge, kpi } from "../ui/components.js";

export function Dashboard(){
  const t = state.getToday();
  const p = state.profile;

  const readinessScore = Number.isFinite(t.readiness.score) ? String(t.readiness.score) : "—";
  const readinessColor = t.readiness.color || "yellow";

  const weightText = Number.isFinite(t.weightAM) ? `${t.weightAM.toFixed(1)}` : "—";
  const macros = t.macros;

  const weighInNeeded = p.weighInRequired && !Number.isFinite(t.weightAM);

  return el("div", { class:"stack" }, [
    card("Readiness", [
      el("div", { class:"row" }, [
        el("div", {}, [
          el("div", { class:"big-num" }, [readinessScore]),
          el("div", { class:"meta" }, [
            `Updated: ${t.readiness.updatedAt ? new Date(t.readiness.updatedAt).toLocaleTimeString() : "—"}`
          ])
        ]),
        el("div", { style:"display:flex; justify-content:flex-end; align-items:flex-start;" }, [
          badge(readinessColor, readinessColor === "green" ? "Green" : readinessColor === "red" ? "Red" : "Yellow")
        ])
      ])
    ]),

    card("Weight", [
      el("div", { class:"big-num" }, [weightText]),
      el("div", { class:"meta" }, [weighInNeeded ? "Weigh-in required this morning." : "Morning weigh-in logged."])
    ]),

    card("Today’s Macros", [
      el("div", { class:"kpis" }, [
        kpi("Calories", `${macros.calories} / ${p.caloriesTarget}`),
        kpi("Protein", `${macros.protein}g / ${p.proteinTarget}g`),
        kpi("Carbs", `${macros.carbs}g / ${p.carbsTarget}g`),
        kpi("Fat", `${macros.fat}g / ${p.fatTarget}g`)
      ])
    ]),

    card("Health (from Watch)", [
      el("div", { class:"kpis" }, [
        kpi("Sleep", Number.isFinite(t.health.sleepMin) ? `${Math.floor(t.health.sleepMin/60)}h ${t.health.sleepMin%60}m` : "—"),
        kpi("HRV", Number.isFinite(t.health.hrv) ? `${t.health.hrv}` : "—"),
        kpi("Resting HR", Number.isFinite(t.health.rhr) ? `${t.health.rhr}` : "—"),
        kpi("Steps", Number.isFinite(t.health.steps) ? `${t.health.steps}` : "—"),
        kpi("Active Cal", Number.isFinite(t.health.activeCalories) ? `${t.health.activeCalories}` : "—"),
      ])
    ]),

    el("div", { class:"row" }, [
      el("button", {
        class:"btn",
        onclick: async () => {
          const v = prompt("Morning weight (lb):");
          if (!v) return;
          const n = Number(v);
          if (!Number.isFinite(n)) return;
          await state.setWeightAM(n);
        }
      }, ["Log Weigh-in"]),
      el("button", {
        class:"btn",
        onclick: async () => {
          const c = Number(prompt("Calories to add:") || "0");
          const pr = Number(prompt("Protein (g) to add:") || "0");
          const ca = Number(prompt("Carbs (g) to add:") || "0");
          const f = Number(prompt("Fat (g) to add:") || "0");
          await state.addMacros({ calories:c, protein:pr, carbs:ca, fat:f });
        }
      }, ["Quick Add Macros"])
    ])
  ]);
}