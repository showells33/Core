function clamp(n,min,max){ return Math.max(min, Math.min(max, n)); }
function avg(nums){
  const arr = nums.filter(n => Number.isFinite(n));
  if (!arr.length) return null;
  return arr.reduce((a,b)=>a+b,0)/arr.length;
}

export function computeReadiness({ profile, today, history }){
  const h = history || [];
  const sleepBase = avg(h.map(d => d?.health?.sleepMin));
  const hrvBase = avg(h.map(d => d?.health?.hrv));
  const rhrBase = avg(h.map(d => d?.health?.rhr));

  const sleep = today.health.sleepMin;
  const hrv = today.health.hrv;
  const rhr = today.health.rhr;

  let sleepScore = 50;
  if (Number.isFinite(sleep) && Number.isFinite(sleepBase) && sleepBase > 0) {
    const ratio = sleep / sleepBase;
    sleepScore = clamp(50 + (ratio - 1) * 80, 15, 100);
  } else if (Number.isFinite(sleep)) {
    sleepScore = clamp((sleep/420)*100, 15, 100);
  }

  let hrvScore = 50;
  if (Number.isFinite(hrv) && Number.isFinite(hrvBase) && hrvBase > 0) {
    const ratio = hrv / hrvBase;
    hrvScore = clamp(50 + (ratio - 1) * 90, 10, 100);
  }

  let rhrScore = 50;
  if (Number.isFinite(rhr) && Number.isFinite(rhrBase) && rhrBase > 0) {
    const delta = (rhr - rhrBase);
    rhrScore = clamp(85 - delta * 6, 10, 100);
  }

  const weighInOk = profile.weighInRequired ? Number.isFinite(today.weightAM) : true;
  const macroSignal = (today.macros.calories > 0 || today.macros.protein > 0) ? 1 : 0;
  const complianceScore = (weighInOk ? 100 : 40) * 0.6 + (macroSignal ? 100 : 70) * 0.4;

  const score = Math.round(
    sleepScore * 0.30 +
    hrvScore   * 0.35 +
    rhrScore   * 0.25 +
    complianceScore * 0.10
  );

  const final = clamp(score, 0, 100);
  let color = "yellow";
  if (final >= 80) color = "green";
  else if (final < 65) color = "red";

  return { score: final, color };
}