import { el } from "./components.js";

const tabs = [
  { hash:"#/dashboard", icon:"⌂", label:"Dashboard" },
  { hash:"#/train", icon:"⌁", label:"Train" },
  { hash:"#/log", icon:"＋", label:"Log" },
  { hash:"#/analytics", icon:"▦", label:"Analytics" }
];

export function mountNav(navEl){
  const inner = el("div", { class:"bottom-nav__inner" }, []);
  navEl.appendChild(inner);

  function render(){
    inner.innerHTML = "";
    for (const t of tabs){
      const active = location.hash === t.hash;
      inner.appendChild(
        el("button", {
          class: active ? "tab tab--active" : "tab",
          onclick: () => { location.hash = t.hash; }
        }, [
          el("span", {}, [t.icon]),
          t.label
        ])
      );
    }
  }

  window.addEventListener("hashchange", render);
  render();
}