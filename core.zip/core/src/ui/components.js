export function el(tag, attrs={}, children=[]){
  const node = document.createElement(tag);
  for (const [k,v] of Object.entries(attrs)){
    if (k === "class") node.className = v;
    else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2).toLowerCase(), v);
    else node.setAttribute(k, v);
  }
  for (const c of children){
    if (c == null) continue;
    node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
  }
  return node;
}

export function card(titleText, bodyNodes=[]){
  return el("section", { class:"card" }, [
    el("h2", { class:"title" }, [titleText]),
    ...bodyNodes
  ]);
}

export function badge(color, text){
  return el("div", { class:"badge" }, [
    el("span", { class:`dot ${color}` }, []),
    text
  ]);
}

export function kpi(label, value){
  return el("div", { class:"kpi" }, [
    el("div", { class:"label" }, [label]),
    el("div", { class:"value" }, [value])
  ]);
}