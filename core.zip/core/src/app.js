import { mountNav } from "./ui/nav.js";
import { router } from "./router.js";
import { state } from "./state.js";
import { initDB } from "./db.js";
import { startAutoSync } from "./sync.js";

async function main(){
  if ("serviceWorker" in navigator) {
    try { await navigator.serviceWorker.register("./sw.js"); } catch {}
  }

  await initDB();
  await state.hydrate();

  mountNav(document.getElementById("bottomNav"));
  router.init(document.getElementById("view"));

  startAutoSync({
    badgeEl: document.getElementById("syncBadge"),
    intervalMs: 5 * 60 * 1000,
  });
}

main();